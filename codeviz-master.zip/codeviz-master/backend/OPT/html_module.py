def display_img(src):
  setHTML('<img src="%s"/>' % str(src))
