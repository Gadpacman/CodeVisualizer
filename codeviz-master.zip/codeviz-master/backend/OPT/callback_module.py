# this module contains a simple callback function to test whether
# callback functions get properly displayed in the trace

def callback_func(func_arg):
  func_arg()
